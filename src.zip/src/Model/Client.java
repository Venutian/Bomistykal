package Model;

public class Client {
}
