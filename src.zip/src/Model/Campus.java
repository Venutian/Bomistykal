package Model;

public class Campus {
}
