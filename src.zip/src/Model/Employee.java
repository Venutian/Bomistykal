package Model;

public class Employee {
}
