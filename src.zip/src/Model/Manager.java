package Model;

public class Manager {
}
